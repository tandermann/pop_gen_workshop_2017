
simulate with selection in the middle,?

use FST windows, for instance

show that pvalue depends on your model, with lower Ne you don't get significance anymore





